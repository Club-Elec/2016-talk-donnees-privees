# Media and Press

We love professional tech writers, journalists, and bloggers. And we are grateful for your interest in Cozy and hope that you can help us to spread the word about it. To make your life a little bit easier, we've prepared a kit that has everything you need to get started with Cozy and write about it. Of course, if you have any questions, don't hesitate to contact us. We'll do our best to help you with your queries.
